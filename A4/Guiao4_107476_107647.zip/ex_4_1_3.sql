DROP SCHEMA IF Exists Gestao_Stocks;
GO
CREATE SCHEMA Gestao_Stocks;
GO

CREATE TABLE PRODUTO(
	Taxa_Iva     INT,
	Codigo       INT           NOT NULL,
	Nome         VARCHAR(15)   NOT NULL,
	Preco        MONEY         NOT NULL,
	Quantidade   INT          NOT NULL,
	PRIMARY KEY(Codigo));

CREATE TABLE FORNECEDOR(
	Nif                  INT            NOT NULL,
	Nome                 VARCHAR(15)    NOT NULL,
	N_Fax                INT,
	Designacao           VARCHAR(15)   NOT  NULL,
	Condicoes_Pagamento  VARCHAR(30),
	Endereco            VARCHAR(15)  ,
	PRIMARY KEY(Nif));

CREATE TABLE ENCOMENDA(
	NEncomenda     INT      NOT NULL,
	Data_E         DATE     NOT NULL,
	Nif_F          INT      NOT NULL,
	PRIMARY KEY(NEncomenda),
	FOREIGN KEY(Nif_F) REFERENCES FORNECEDOR(Nif));


CREATE TABLE CONTEM(
	NEncomenda_E       INT    NOT NULL,
	Codigo_P           INT   NOT NULL,
	PRIMARY KEY(NEncomenda_E,Codigo_P),
	FOREIGN KEY(NEncomenda_E) REFERENCES ENCOMENDA(NEncomenda),
	FOREIGN KEY(Codigo_P) REFERENCES PRODUTO (Codigo));


