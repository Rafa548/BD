DROP TABLE IF Exists CLIENTE,BALCAO,TIPO_VEICULO,VEICULO,ALUGER,LIGEIRO,PESADO,SIMILARIDADE;
DROP SCHEMA IF Exists Rent_Car;
GO
CREATE SCHEMA Rent_Car;
GO


 

CREATE TABLE CLIENTE (
	Nome          VARCHAR(15)      NOT NULL,        
	Endere�o      VARCHAR(30),
	Nif           INT              NOT NULL,
	N_Carta       INT              NOT NULL,
	PRIMARY KEY(Nif));

CREATE TABLE BALCAO(	
	Nome    VARCHAR(15),
	Endereco   VARCHAR(30)     NOT NULL,  
	Numero      INT            NOT NULL,
	PRIMARY KEY(Numero));

CREATE TABLE TIPO_VEICULO(
	Arcondicionado   BIT,
	Codigo           INT             NOT NULL,
	Designacao       VARCHAR(15)     NOT NULL,
	PRIMARY KEY(Codigo));



CREATE TABLE VEICULO(
	Matricula    VARCHAR(6)        NOT NULL,
	Ano          INT,
	Marca        VARCHAR(15),
	Codigo_T     INT               NOT NULL,
	PRIMARY KEY(Matricula),
	FOREIGN KEY(Codigo_T) REFERENCES TIPO_VEICULO(Codigo));

CREATE TABLE ALUGER(
	Duracao      DECIMAL(3,1)           NOT NULL,
	Data_Alug         DATE,
	Numero           INT                NOT NULL,
	Num_Balcao        INT                NOT NULL,
	Nif_Cliente       INT                NOT NULL,
	Matricula_veic    VARCHAR(6)         NOT NULL,
	PRIMARY KEY(Numero),
	FOREIGN KEY(Num_Balcao) REFERENCES BALCAO (Numero),
    FOREIGN KEY(Nif_Cliente) REFERENCES CLIENTE(Nif),
	FOREIGN KEY(Matricula_veic) REFERENCES VEICULO(Matricula));

CREATE TABLE LIGEIRO(
	Portas      INT           NOT NULL,
	N_lugares  INT            NOT NULL,
	Combustivel  VARCHAR(15),
	Codigo_V       INT        NOT NULL,
	PRIMARY KEY(Codigo_V),
	FOREIGN KEY(Codigo_V) REFERENCES TIPO_VEICULO(Codigo));

CREATE TABLE PESADO(
	Peso        INT           NOT NULL,
	Passageiros INT,
	Codigo_V       INT        NOT NULL,
	PRIMARY KEY(Codigo_V),
	FOREIGN KEY(Codigo_V) REFERENCES TIPO_VEICULO(Codigo));

CREATE TABLE SIMILARIDADE(
	Codigo_M       INT     NOT NULL,
	Codigo_N      INT       NOT NULL,
	FOREIGN KEY(Codigo_M) REFERENCES TIPO_VEICULO(Codigo),
	FOREIGN KEY(Codigo_N) REFERENCES TIPO_VEICULO(Codigo));
	 
