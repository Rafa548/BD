DROP SCHEMA IF Exists ATL;
GO
CREATE SCHEMA ATL;
GO

CREATE TABLE PESSOA(
	N�CC       INT    NOT NULL,
	Morada     VARCHAR(30),
	Nome       VARCHAR(15)  NOT NULL,
	DatadeNascimento    DATE ,
	PRIMARY KEY(N�CC));

CREATE TABLE PROFESSOR(
	P_N�CC        INT               NOT NULL,
	Contacto      VARCHAR(9)               ,
	Email         VARCHAR(30)       ,
	N�deFuncionario   INT       NOT NULL,
	PRIMARY KEY(N�deFuncionario),
	FOREIGN KEY(P_N�CC) REFERENCES PESSOA(N�CC));


CREATE TABLE TURMA(
	Identificador      INT        NOT NULL,
	AnoLetivo           INT        NOT NULL,
	Designacao           VARCHAR(15) ,
	N�MaxAlunos          INT       ,
	Prof_N�deFuncionario   INT       NOT NULL,
	PRIMARY KEY(Identificador) ,
	FOREIGN KEY (Prof_N�deFuncionario) REFERENCES PROFESSOR(N�deFuncionario));

CREATE TABLE EE(
	EC_N�CC      INT     NOT NULL,
	Contacto     VARCHAR(9)     ,
	Email        VARCHAR(30),
	Relacao      VARCHAR(15),
	PRIMARY KEY(EC_N�CC),
	FOREIGN KEY(EC_N�CC ) REFERENCES PESSOA(N�CC));

CREATE TABLE OUTRASP(
		OP_N�CC    INT    NOT NULL,
		PRIMARY KEY(OP_N�CC),
		FOREIGN KEY(OP_N�CC) REFERENCES PESSOA(N�CC));

CREATE TABLE ALUNO(
	A_N�CC     INT       NOT NULL,
	A_Turma    INT        NOT NULL,
	E_N�CC      INT       NOT NULL,
	PRIMARY KEY(A_N�CC),
	FOREIGN KEY(A_N�CC ) REFERENCES PESSOA(N�CC),
	FOREIGN KEY(A_Turma ) REFERENCES TURMA(Identificador),
	FOREIGN KEY(E_N�CC) REFERENCES  EE(EC_N�CC));


