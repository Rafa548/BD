DROP TABLE IF EXISTS Airport;
DROP TABLE IF EXISTS Airplane_Type;
DROP TABLE IF EXISTS Can_Land;
DROP TABLE IF EXISTS Flight;
DROP TABLE IF EXISTS Fare;
DROP TABLE IF EXISTS Flight_Leg;
DROP TABLE IF EXISTS Airplane;
DROP TABLE IF EXISTS Leg_Instance;
DROP TABLE IF EXISTS Seat;
DROP SCHEMA IF EXISTS Reserva_Voo;
GO
CREATE SCHEMA Reserva_Voo;
GO


Create Table Airport(
	Airport_Code		Int				Not null,
	City				Varchar(30)		Not null,
	State_A				Varchar(10) 	Not null,
	Name_A				Varchar(20)  	Not null,
	Primary Key (Airport_Code));

Create Table Airplane_Type(
	Type_name_		Varchar(10)       Not null,
	Company			Varchar(15)       Not null,
	Max_Seats		Int				  Not null,
	Primary Key(Type_name_));

Create  Table Can_Land (
	A_Airport_Code		Int       		Not null,
	AT_Type_Name		Varchar(10)     Not null,
	Primary Key(A_Airport_Code,AT_Type_Name),
	Foreign Key(A_Airport_Code) References Airport(Airport_code),
	Foreign Key(AT_Type_Name) References Airplane_Type(Type_name_));

Create Table Flight(
	Number_		Int				Not null,
	Airline		Varchar(20)	 	Not null,
	Weekdays	Varchar(30)		Not null,
	Primary Key(Number_));

Create Table Fare (
	Code			Int    		 	 Not null,
	Amount			Money			 Not null,
	Restrictions	Varchar(20),
	F1_Number		Int			 	 Not null,
	Primary Key(Code,F1_Number),
	Foreign Key(F1_Number) References Flight(Number_));

Create Table Flight_Leg(
	Leg_no				Int     Not null,
	A2_Airport_Code		Int     Not null,
	F_Number			Int     Not null,
	S_arr_time			Time	Not null,
	S_dep_time			Time	Not null,
	Primary Key(Leg_No,F_Number),
	Foreign Key(F_Number) References Flight(Number_), 
	Foreign Key(A2_Airport_Code) References Airport(Airport_Code));

Create Table Airplane(
	Airplane_id				Int   		 Not null,
	Total_no_of_seats		Int   		 Not null,
	AT1_Type_Name			Varchar(10)  Not null,
	Primary Key(Airplane_id),
	Foreign Key(AT1_Type_Name) References Airplane_Type(Type_name_));

Create Table Leg_Instance(
	No_of_avail_seats	Int		Not null,
	Date_				DATE	Not null,
	A_Airplane_id		Int		Not null,
	A_Airport_code		Int 	Not null,
	Fl_Leg_no			Int 	Not null,
	Fl_F_Number			Int 	Not null,
	Arr_time			Time    Not null,
	Dep_time			Time    Not null,
	Primary Key(Date_,Fl_Leg_no,Fl_F_Number),
	Foreign Key(A_Airplane_id) References Airplane(Airplane_id),
	Foreign Key(A_Airport_code) References Airport(Airport_Code),
	Foreign Key(Fl_Leg_no,Fl_F_Number) References Flight_Leg(Leg_no,F_Number));

Create Table Seat(
	Seat_no			Int 			Not null,
	Customer_name	VarChar(15) 	Not null,
	Cphone_			VarChar(10) 	Not null,
	LI_Date			DATE 			Not null,
	LI_Leg_no		Int 			Not null,
	LI_Fl_Number 	Int 			Not null,
	Primary Key(Seat_no,LI_Date,LI_Leg_no,LI_Fl_Number),
	Foreign Key(LI_Date,LI_Leg_no,LI_Fl_Number) References Leg_Instance(Date_,Fl_Leg_no,Fl_F_Number));