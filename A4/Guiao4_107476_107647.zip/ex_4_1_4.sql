DROP TABLE IF EXISTS Medico;
DROP TABLE IF EXISTS Paciente;
DROP TABLE IF EXISTS Farmacia;
DROP TABLE IF EXISTS Farmaceutica;
DROP TABLE IF EXISTS Prescricao;
DROP TABLE IF EXISTS Farmaco;
DROP SCHEMA IF EXISTS Prescricao_Med;
GO
CREATE SCHEMA Prescricao_Med;
GO


CREATE TABLE Medico(
    Nome                VARCHAR(30)     NOT NULL,
    N_Identificacao     INT             NOT NULL,
    Especialidade       VARCHAR(30)     NOT NULL,
    PRIMARY KEY (N_Identificacao)	
);

CREATE TABLE Paciente(
    Nome                    VARCHAR(30)     NOT NULL,
    N_Utente                INT             NOT NULL,
    Data_Nascimento         DATE            NOT NULL,
    Endereco                VARCHAR(30)      NOT NULL,
    PRIMARY KEY (N_Utente)
);

CREATE TABLE Farmacia(
    Nome                    VARCHAR(30)     NOT NULL,
    NIF                     INT             NOT NULL,
    Endereco                VARCHAR(30)     NOT NULL,
    Telefone                VARCHAR(9)      NOT NULL,
    PRIMARY KEY (NIF)
);

Create TABLE Farmaceutica(
    Nome                    VARCHAR(30)     NOT NULL,
    N_Registo_Nacional      INT             NOT NULL,
    Endereco                VARCHAR(30)     NOT NULL,
    Telefone                VARCHAR(9)      NOT NULL,
    PRIMARY KEY (N_Registo_Nacional)
);

CREATE TABLE Prescricao(
    Numero                  INT             NOT NULL,
    Data_                   DATE            NOT NULL,
    N_Utente_P              INT             NOT NULL,
    NIF_F                   INT             NOT NULL,
    N_Identificacao_M       INT             NOT NULL,
    PRIMARY KEY (Numero,N_Utente_P,NIF_F,N_Identificacao_M),
    FOREIGN KEY (N_Utente_P) REFERENCES Paciente(N_Utente),
    FOREIGN KEY (NIF_F) REFERENCES Farmacia(NIF),
    FOREIGN KEY (N_Identificacao_M) REFERENCES Medico(N_Identificacao)
);

CREATE TABLE Farmaco(
    Nome                    VARCHAR(30)     NOT NULL,
    Nome_Comercial          VARCHAR(30)     NOT NULL,
    Formula                 VARCHAR(30)     NOT NULL,
    P_N_Utente_P            INT             NOT NULL,
    P_NIF_F                 INT             NOT NULL,
    P_N_Identificacao_M     INT             NOT NULL,
    P_Numero                INT             NOT NULL,
    F_N_Registo_Nacional    INT             NOT NULL,
    PRIMARY KEY (Formula,P_N_Utente_P,P_NIF_F,P_N_Identificacao_M,P_Numero,F_N_Registo_Nacional),
    FOREIGN KEY (P_N_Utente_P,P_NIF_F,P_N_Identificacao_M,P_Numero) REFERENCES Prescricao(Numero,N_Utente_P,NIF_F,N_Identificacao_M),
    FOREIGN KEY (F_N_Registo_Nacional) REFERENCES Farmaceutica(N_Registo_Nacional)
);

