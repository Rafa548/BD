DROP TABLE IF Exists ARTIGO,PARTICIPANTE,AUTOR,ESTUDANTE,NAO_ESTUDANTE,FEZ_O_ARTIGO;
DROP SCHEMA IF Exists Gestao_Conferencias;
GO
CREATE SCHEMA Gestao_Conferencias;
GO

CREATE TABLE ARTIGO(
	N�Registo     INT            NOT NULL,
	Titulo         VARCHAR(15)   ,
	PRIMARY KEY(N�Registo));

CREATE TABLE PARTICIPANTE(
	Nome       VARCHAR(15)      NOT NULL,
	Morada     VARCHAR(30)     ,
	Email      VARCHAR(15)    ,
	Instituicao  VARCHAR(15) ,
	Data_Inscricao   DATE    ,
	PRIMARY KEY(Nome));

CREATE TABLE FEZ_O_ARTIGO(
	N�Autor     INT    NOT NULL,
	N�Registo_Artigo    INT   NOT NULL,
	PRIMARY KEY(N�Registo_Artigo),
	FOREIGN KEY(N�Registo_Artigo) REFERENCES ARTIGO(N�Registo));

CREATE TABLE AUTOR(
	Nome        VARCHAR(15)  NOT NULL,
	Email       VARCHAR(15) ,
	Instituicao  VARCHAR(15) ,
	Nome_Instituicao VARCHAR(15) ,
	Endereco        VARCHAR(15) ,
	PRIMARY KEY(Nome));

CREATE TABLE ESTUDANTE(
	Nome2        VARCHAR(15)  NOT NULL,
	Comprovativo        VARCHAR(15) ,
	Isento_de_pagamento   BIT     ,
	PRIMARY KEY(Nome2),
	FOREIGN KEY(Nome2) REFERENCES PARTICIPANTE(Nome));

CREATE TABLE NAO_ESTUDANTE(
	Nome1        VARCHAR(15)  NOT NULL,
	Reg           VARCHAR(30) ,
	PRIMARY KEY(Nome1),
	FOREIGN KEY(Nome1) REFERENCES PARTICIPANTE(Nome));



