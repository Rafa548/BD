# BD: Guião 3


## ​Problema 3.1
 
### *a)*

```
    Cliente(nome,endereco,n_carta,nif)
    Aluguer(numero,duracao,data)
    Balcao(nome,numero,endereco)
    Veiculo(matricula,marca,ano)
    Tipo_Veiculo(designacao,arcondicionado,codigo)
    Ligeiro(n_lugares,portas,combustivel)
    Pesado(peso,passageiros)
```


### *b)* 

```
    Primarias e Candidatas
        Cliente->Nif
        Aluguer->numero
        Balcao->numero
        Veiculo->matricula
        Tipo_Veiculo->codigo
        Pesado->codigo
        Ligeiro->codigo
    
    Unicas
        ...

    Estrangeiras
        Cliente->
        Aluguer->num_balcao,nif_cliente,veic_matricula
        Balcao->
        Tipo_veic->
        Veiculo->codigo_T
        Similariadade -> codigo_M,codigo_N
        Pesado->codigo_V
        Ligeiro->codigo_V
```


### *c)* 

![ex_3_1c!](ex_3_1c.jpg "AnImage")


## ​Problema 3.2

### *a)*

```
    Airport(Airport_code,city,state,name)
    Flight_Leg(Leg_no)
    Flight(Number,Airline,Weekdays)
    Fare(Restrictions,Amount,Code)
    Leg_Instance(No_of_avail_seats,Date)
    Airplane(Airplane_id,Total_no_of_seats)
    Seat(Seat_no)
    Airplane_type(Company,Type_name,Max_seats)
```


### *b)* 

```
    Chaves primárias e candidatas:
    Airport->Airport_Code
    Flight->
    Flight_Leg->F_Number
    Fare->
    Leg_Instnce->A_Airplane_id
    Seat->
    Airplane->

    Chaves estrangeiras:
    Airport->
    Flight->
    CanLand->AT_Type_Name
    Flight_Leg->A2_Airport_Code
    Fare->F1_Number
    Leg_Instnce->A_Airplane_id
    Seat->LI_No_of_avail_seats
    Airplane->AT1_Type_Nme
```


### *c)* 

![ex_3_2c!](ex_3_2c.jpg "AnImage")


## ​Problema 3.3


### *a)* 2.1

![ex_3_3_a!](ex_3_3a.jpg "AnImage")

### *b)* 2.2

![ex_3_3_b!](ex_3_3b.jpg "AnImage")

### *c)* 2.3

![ex_3_3_c!](ex_3_3c.jpg "AnImage")

### *d)* 2.4

![ex_3_3_d!](ex_3_3d.jpg "AnImage")